# Odoo Debranding

Odoo Debranding is a tool to remove the odoo promotions and links and replace it with your custom details. Dialogues, popup windows, social icons, footer, header and all related stuff can be changed with your company data. This will update the following details.

License
----
[![License: AGPL v3](https://img.shields.io/badge/License-AGPL%20v3-blue.svg)](https://www.gnu.org/licenses/agpl-3.0)
